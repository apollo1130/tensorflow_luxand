#include "../WireGuardKitC/WireGuardKitC.h"
#include "../WireGuardKitGo/wireguard.h"
#include "ringlogger.h"
