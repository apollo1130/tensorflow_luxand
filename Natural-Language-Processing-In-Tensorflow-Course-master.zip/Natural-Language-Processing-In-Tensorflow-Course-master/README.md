# NLP_In_Tensorflow-Course

This repository contains Excercise Notebooks of Course 3-Natural Language Processing in Tensorflow of **Tensorflow in Practice Specialization.**

#### Download Dataset for Week 1, 2 Exercise Notebook:
https://storage.googleapis.com/laurencemoroney-blog.appspot.com/bbc-text.csv

#### Download Dataset for Week 3 Exercise Notebook:
https://storage.googleapis.com/laurencemoroney-blog.appspot.com/training_cleaned.csv

#### Download Dataset for Week 4 Exercise Notebook:
https://storage.googleapis.com/laurencemoroney-blog.appspot.com/sonnets.txt
