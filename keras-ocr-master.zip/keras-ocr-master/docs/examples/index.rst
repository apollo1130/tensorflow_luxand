Examples
********

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   using_pretrained_models
   end_to_end_training
   fine_tuning_detector
   fine_tuning_recognizer