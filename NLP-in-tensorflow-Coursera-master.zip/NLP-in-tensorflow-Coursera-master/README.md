# [Coursera] Natural Language Processing in Tensorflow

## Description

This is a repository about [NLP in Tensorflow course from Coursera](https://www.coursera.org/learn/natural-language-processing-tensorflow)

Tensorflow Dataset: https://www.tensorflow.org/datasets/catalog/overview

## Certificate

![CERTIFICATE_LANDING_PAGE_T9FR5XLCTTGG](https://user-images.githubusercontent.com/36662761/119678632-a5b01500-be7a-11eb-808d-84b0e289e11d.jpeg)

[Certificate Verification](https://coursera.org/share/17b3f00546457b445f232db79f1e7424)